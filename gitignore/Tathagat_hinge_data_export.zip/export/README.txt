Welcome to your Data Export!

What is included:

1. An 'index.html' file that provides a readable report of your data.
2. A directory of media files you uploaded (or linked via social media).
3. machine-readable data files
    * user.json
    * subscriptions.json
    * matches.json
    * media.json
    * prompts.json
    * fresh_starts.json
    * selfie_verification.json
    * match_notes.json
    * prompt_feedback.json


Instructions for viewing your data:

1. Navigate to the directory containing this file.
2. Open the index.html in your web browser (you may be able to "double-click" index.html and it will open in your default web browser).
